public class CurrentAccount extends Account {

 private double overdraftLimit;

 public CurrentAccount(String accountNumber, double balance, double overdraftLimit) {
    super(accountNumber, balance);
    this.overdraftLimit = overdraftLimit;
}  
@Override
public void withdraw(double amount) {
    if (balance - amount < -overdraftLimit) {
        System.out.println("Withdrawal rejected: overdraft limit exceeded.");
    } else {
        balance -= amount;
        System.out.println("Withdrawal successful: " + amount);
    }
}
@Override
public void endOfMonth() {
    double maintenanceFee = 5.00;
    balance -= maintenanceFee;
    System.out.println("Monthly maintenance fee deducted: " + maintenanceFee);
}
}

