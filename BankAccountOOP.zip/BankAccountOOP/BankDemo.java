import java.util.ArrayList;
import java.util.List;

public class BankDemo {

    public static void main(String[] args) {

        List<Account> accounts = new ArrayList<>();

        accounts.add(new SavingsAccount("S001", 1000.00, 500.00));
        accounts.add(new CurrentAccount("C001", 500.00, 300.00));

        double[] withdrawalAmounts = {600.00, 700.00};

        for (int i = 0; i < accounts.size(); i++) {

            Account account = accounts.get(i);

            System.out.println("\n--- Testing Account ---");

            account.withdraw(withdrawalAmounts[i]);
            account.endOfMonth();
        }
    }
}