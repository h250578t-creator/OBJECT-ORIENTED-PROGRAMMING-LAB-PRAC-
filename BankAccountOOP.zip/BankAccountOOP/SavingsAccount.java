
public class SavingsAccount extends Account {
private double minimumBalance;

public SavingsAccount(String accountNumber, double balance, double minimumBalance) {
    super(accountNumber, balance);
    this.minimumBalance = minimumBalance;
}
@Override
public void withdraw(double amount) {
    if (balance - amount < minimumBalance) {
        System.out.println("Withdrawal rejected: minimum balance must be maintained.");
    } else {
        balance -= amount;
        System.out.println("Withdrawal successful: " + amount);
    }
}
@Override
public void endOfMonth() {
    double interestRate = 0.02;
    double interest = balance * interestRate;
    balance += interest;

    System.out.println("Monthly interest added: " + interest);
}
}  